// global.js
var primes = [2,3,5,7,11,13];
